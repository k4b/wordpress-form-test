<?php
  $filename = $_POST['id'];

  unlink($filename);
?>